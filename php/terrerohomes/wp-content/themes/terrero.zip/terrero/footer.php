<?php
/**
 * The template for displaying the footer
 *
 * Contains footer content and the closing of the #main and #page div elements.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?>
	</div><!-- #main .wrapper -->
	<footer id="colophon" role="contentinfo">
		<div class="site-info">			
			<a href="http://aneudyabreu.com" title="aneudybreu.com">Developed by aneudyabreu.com from Web Solutions</a>
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->
<!-- <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script> -->
<script type="text/javascript">
var $ = $ || jQuery;
$(function(){
	var w = $(window).width(),
	    toggle 		= $('#toggle-menu'),
	    menu 		= $('nav ul'),
	    hasChild = $('.has-child'),
	    dropdown = $('.dropdown');

	$(function() {
	  $(toggle).on('click', function(e) {
	    e.preventDefault();
	    menu.toggle();
	  });
	  
	  $(hasChild).click(function(e) {
	    // e.preventDefault();
	    dropdown.toggle();
	  });
	});

	$(window).resize(function(){
	  if(w > 320 && menu.is(':hidden')) {
	    menu.removeAttr('style');}
	});
});

		



</script>



<?php wp_footer(); ?>
</body>
</html>