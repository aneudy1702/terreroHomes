<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * For example, it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Terrero
 * @since Twenty Twelve 1.0
 */

	get_header('main-page'); ?>
	<?php //if ( function_exists( 'meteor_slideshow' ) ) { meteor_slideshow(); } ?>				

	
	<div id="primary" class="site-content home-page grid-c">		
		<div id="content" role="main">			

			<section>
				<center>
					<h1>Something about the website</h1>	
				</center>
				
				<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
				Aenean commodo ligula eget dolor. Aenean massa.
				Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.
				Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.
				</p>
				<p>
					Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.
				In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium.
				Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus.
				
				</p>
				<p>
					Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.
				Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet.
				Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi.
				Nam eget dui. Etiam rhoncus.
				</p>
				<p>
					Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum.
				Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus.
				Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt.
				Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna.
				</p>
				<p>
					Sed consequat, leo eget bibendum sodales, augue velit cursus nunc,
				</p>				
			</section>

			<!-- cities -->
			<section>
				<center>
					<h1>Get Listings by cities</h1>
				</center>
				<div class="cities-container">
					<ul>
						<li class="city-item">
							<a href="">
								<div class="city-content">
									<div>
										<img src="/terrerohomes/wp-content/uploads/2015/10/bronx.jpg">
										<div class="city-name">											
											Bronx											
										</div>
									</div>
								</div>
							</a>							
						</li>
						<li class="city-item">
							<a href="">
								<div class="city-content">
									<div>
										<img src="/terrerohomes/wp-content/uploads/2015/10/nyc-manhattan.jpg">
										<div class="city-name">											
											Manhattan
										</div>
									</div>
								</div>
							</a>							
						</li>
						<li class="city-item">
							<a href="">
								<div class="city-content">
									<div>
										<img src="/terrerohomes/wp-content/uploads/2015/10/queens.jpg">
										<div class="city-name">											
											Queens											
										</div>
									</div>
								</div>
							</a>							
						</li>
					</ul>
				</div>
			</section>
			<!-- cities -->
		</div><!-- #content -->
	</div><!-- #primary -->

<?php //get_sidebar(); ?> 
<?php get_footer(); ?>
